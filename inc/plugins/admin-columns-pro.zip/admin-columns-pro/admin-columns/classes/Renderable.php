<?php

namespace AC;

interface Renderable {

	/**
	 * @return string
	 */
	public function render();

}