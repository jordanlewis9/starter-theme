<?php

namespace AC;

use AC;

interface AdminFactoryInterface {

	/**
	 * @return AC\Admin
	 */
	public function create();

}