<?php

namespace ACP\Sorting;

interface Sortable {

	/**
	 * @return AbstractModel
	 */
	public function sorting();

}